import matplotlib.pyplot as plt
from sklearn import datasets
from sklearn.cluster import KMeans
from sklearn.mixture import GaussianMixture
from sklearn import preprocessing
import sklearn.metrics as sm
import pandas as pd
import numpy as np

# Load dataset
iris = datasets.load_iris()

X = pd.DataFrame(iris.data)
X.columns = ['Sepal_Length', 'Sepal_Width', 'Petal_Length', 'Petal_Width']

y = pd.DataFrame(iris.target)
y.columns = ['Targets']

# ------------------ KMEANS ------------------
model = KMeans(n_clusters=3, random_state=42)
model.fit(X)

plt.figure(figsize=(14,7))

colormap = np.array(['red','lime','black'])

# Real Classification
plt.subplot(1,3,1)
plt.scatter(X.Petal_Length, X.Petal_Width,
            c=colormap[y.Targets], s=40)
plt.title('Real Classification')
plt.xlabel('Petal Length')
plt.ylabel('Petal Width')

# KMeans Classification
plt.subplot(1,3,2)
plt.scatter(X.Petal_Length, X.Petal_Width,
            c=colormap[model.labels_], s=40)
plt.title('K-Means Classification')
plt.xlabel('Petal Length')
plt.ylabel('Petal Width')

print("Accuracy score of K-Means:",
      sm.accuracy_score(y.values.ravel(), model.labels_))

print("Confusion Matrix of K-Means:\n",
      sm.confusion_matrix(y.values.ravel(), model.labels_))


# ------------------ GMM ------------------
scaler = preprocessing.StandardScaler()
xsa = scaler.fit_transform(X)

xs = pd.DataFrame(xsa, columns=X.columns)

gmm = GaussianMixture(n_components=3, random_state=42)
gmm.fit(xs)

y_gmm = gmm.predict(xs)

# GMM Classification Plot
plt.subplot(1,3,3)
plt.scatter(X.Petal_Length, X.Petal_Width,
            c=colormap[y_gmm], s=40)
plt.title('GMM (EM) Classification')
plt.xlabel('Petal Length')
plt.ylabel('Petal Width')

print("Accuracy score of EM:",
      sm.accuracy_score(y.values.ravel(), y_gmm))

print("Confusion Matrix of EM:\n",
      sm.confusion_matrix(y.values.ravel(), y_gmm))

plt.tight_layout()
plt.show()