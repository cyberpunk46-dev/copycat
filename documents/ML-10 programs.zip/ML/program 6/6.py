import pandas as pd
print("="*20)
print("Program 6")
print("="*20)
msg = pd.read_csv(r"C:\Users\2AI1\Documents\ML\program 6\data.csv",header=None,names=['id', 'message', 'label'])
print('The dimensions of the dataset', msg.shape)
msg['labelnum'] = msg.label.map({'pos':1, 'neg':0})
X = msg.message
y = msg.labelnum
print("\nMessages:\n")
print(X)
print("\nLabels:\n")
print(y)
from sklearn.model_selection import train_test_split
xtrain, xtest, ytrain, ytest = train_test_split(
    X, y, random_state=42
)
print('\nThe total number of Training Data :', ytrain.shape)
print('\nThe total number of Test Data :', ytest.shape)
from sklearn.feature_extraction.text import CountVectorizer
count_vect = CountVectorizer()
xtrain_dtm = count_vect.fit_transform(xtrain)
xtest_dtm = count_vect.transform(xtest)
print('\nThe words or Tokens in the text documents:\n')
print(count_vect.get_feature_names_out())
df = pd.DataFrame(
    xtrain_dtm.toarray(),
    columns=count_vect.get_feature_names_out()
)
from sklearn.naive_bayes import MultinomialNB
clf = MultinomialNB().fit(xtrain_dtm, ytrain)

predicted = clf.predict(xtest_dtm)
from sklearn import metrics
print('\nAccuracy of the classifier is',
      metrics.accuracy_score(ytest, predicted))
print('\nConfusion matrix')
print(metrics.confusion_matrix(ytest, predicted))
print('\nThe value of Precision',
      metrics.precision_score(ytest, predicted))
print('\nThe value of Recall',
      metrics.recall_score(ytest, predicted))