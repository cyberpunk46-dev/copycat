import numpy as np
import pandas as pd
from pgmpy.estimators import MaximumLikelihoodEstimator
from pgmpy.models import DiscreteBayesianNetwork
from pgmpy.inference import VariableElimination
print("="*20)
print("Program 7")
print("="*20)
# Load dataset
heartDisease = pd.read_csv(r"C:\Users\2AI1\Documents\ML\program 7\heart.csv")
heartDisease = heartDisease.replace('?', np.nan)

print("Sample instances from dataset")
print(heartDisease.head())

print("\nAttributes and datatypes")
print(heartDisease.dtypes)

# Create Bayesian Model
model = DiscreteBayesianNetwork([
    ('age','heartdisease'),
    ('sex','heartdisease'),
    ('exang','heartdisease'),
    ('cp','heartdisease'),
    ('heartdisease','restecg'),
    ('heartdisease','chol')
])

print("\nLearning CPD using Maximum Likelihood Estimator")
model.fit(heartDisease, estimator=MaximumLikelihoodEstimator)

# Inference
print("\nInferencing with Bayesian Network:")
HeartDiseasetest_infer = VariableElimination(model)

print("\n1. Probability of HeartDisease given restecg")
q1 = HeartDiseasetest_infer.query(
    variables=['heartdisease'],
    evidence={'restecg':0}
)
print(q1)

print("\n2. Probability of HeartDisease given cp")
q2 = HeartDiseasetest_infer.query(
    variables=['heartdisease'],
    evidence={'cp':2}
)
print(q2)